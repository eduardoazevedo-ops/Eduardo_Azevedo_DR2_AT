﻿class Funcionario
{
    public string Nome;
    public string Cargo;
    public double Salario;

    public double CalcularSalario()
    {
        return Salario;
    }
}