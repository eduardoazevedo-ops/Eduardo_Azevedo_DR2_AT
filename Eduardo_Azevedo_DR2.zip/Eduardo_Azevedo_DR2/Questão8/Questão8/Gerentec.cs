﻿class Gerente : Funcionario
{
    public double CalcularSalario()
    {
        return Salario * 1.20;
    }
}