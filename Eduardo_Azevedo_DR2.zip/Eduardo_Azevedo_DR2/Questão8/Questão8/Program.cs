﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Funcionario funcionario = new Funcionario();

            funcionario.Nome = "Carlos";
            funcionario.Cargo = "Programador";
            funcionario.Salario = 3000;

            Gerente gerente = new Gerente();

            gerente.Nome = "João";
            gerente.Cargo = "Gerente";
            gerente.Salario = 5000;

            Console.WriteLine("Funcionário: " + funcionario.Nome);
            Console.WriteLine("Salário: R$ " + funcionario.CalcularSalario());

            Console.WriteLine();

            Console.WriteLine("Gerente: " + gerente.Nome);
            Console.WriteLine("Salário: R$ " + gerente.CalcularSalario());
        }
    }
}