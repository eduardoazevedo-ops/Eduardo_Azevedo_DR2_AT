﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int numeroSorteado = random.Next(1, 51);
            int tentativas = 5;

            Console.WriteLine("Adivinhe um número de 1 a 50!");

            for (int i = 1; i <= tentativas; i++)
            {
                Console.Write("Tentativa " + i + ": ");
                int numero = int.Parse(Console.ReadLine());

                if (numero < 1 || numero > 50)
                {
                    Console.WriteLine("Erro: digite um número entre 1 e 50.");
                    i--;
                    continue;
                }

                if (numero == numeroSorteado)
                {
                    Console.WriteLine("Você acertou!");
                    return;
                }
                else if (numero < numeroSorteado)
                {
                    Console.WriteLine("O número é maior.");
                }
                else
                {
                    Console.WriteLine("O número é menor.");
                }
            }

            Console.WriteLine("Você perdeu!");
            Console.WriteLine("O número era: " + numeroSorteado);
        }
    }
}