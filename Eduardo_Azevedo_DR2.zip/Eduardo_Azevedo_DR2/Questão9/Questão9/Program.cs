﻿using System;
using System.IO;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string arquivo = "estoque.txt";

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("1 - Inserir Produto");
                Console.WriteLine("2 - Listar Produtos");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha uma opção: ");

                int opcao = int.Parse(Console.ReadLine());

                if (opcao == 1)
                {
                    Console.Write("Nome do produto: ");
                    string nome = Console.ReadLine();

                    Console.Write("Quantidade: ");
                    int quantidade = int.Parse(Console.ReadLine());

                    Console.Write("Preço: ");
                    double preco = double.Parse(Console.ReadLine());

                    using (StreamWriter escritor = new StreamWriter(arquivo, true))
                    {
                        escritor.WriteLine(nome + "," + quantidade + "," + preco);
                    }

                    Console.WriteLine("Produto cadastrado!");
                }
                else if (opcao == 2)
                {
                    if (!File.Exists(arquivo))
                    {
                        Console.WriteLine("Nenhum produto cadastrado.");
                    }
                    else
                    {
                        using (StreamReader leitor = new StreamReader(arquivo))
                        {
                            string linha;

                            while ((linha = leitor.ReadLine()) != null)
                            {
                                string[] dados = linha.Split(',');

                                Console.WriteLine(
                                    "Produto: " + dados[0] +
                                    " | Quantidade: " + dados[1] +
                                    " | Preço: R$ " + dados[2]
                                );
                            }
                        }
                    }
                }
                else if (opcao == 3)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Opção inválida!");
                }
            }
        }
    }
}