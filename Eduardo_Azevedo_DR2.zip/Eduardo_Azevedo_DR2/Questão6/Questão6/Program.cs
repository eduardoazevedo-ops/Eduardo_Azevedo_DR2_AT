﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno = new Aluno();

            aluno.Nome = "Eduardo";
            aluno.Matricula = "123456";
            aluno.Curso = "Engenharia de Software";
            aluno.Media = 8;

            aluno.ExibirDados();
        }
    }
}