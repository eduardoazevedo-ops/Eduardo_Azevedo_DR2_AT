﻿using System;

class Aluno
{
    public string Nome;
    public string Matricula;
    public string Curso;
    public double Media;

    public void ExibirDados()
    {
        Console.WriteLine("Nome: " + Nome);
        Console.WriteLine("Matrícula: " + Matricula);
        Console.WriteLine("Curso: " + Curso);
        Console.WriteLine("Média: " + Media);
        Console.WriteLine("Situação: " + VerificarAprovacao());
    }

    public string VerificarAprovacao()
    {
        if (Media >= 7)
            return "Aprovado";
        else
            return "Reprovado";
    }
}