﻿using System;
using System.Collections.Generic;

class ContatoFormatter
{
    public virtual void ExibirContatos(List<Contato> contatos)
    {
        foreach (Contato contato in contatos)
        {
            Console.WriteLine($"Nome: {contato.Nome}");
            Console.WriteLine($"Telefone: {contato.Telefone}");
            Console.WriteLine($"Email: {contato.Email}");
        }
    }
}