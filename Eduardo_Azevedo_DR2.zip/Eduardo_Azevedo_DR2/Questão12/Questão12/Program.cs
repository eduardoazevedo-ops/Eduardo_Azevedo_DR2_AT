﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string arquivo = "contatos.txt";
            List<Contato> contatos = new List<Contato>();

            if (File.Exists(arquivo))
            {
                using (StreamReader leitor = new StreamReader(arquivo))
                {
                    string linha;

                    while ((linha = leitor.ReadLine()) != null)
                    {
                        string[] dados = linha.Split(',');

                        Contato contato = new Contato();

                        contato.Nome = dados[0];
                        contato.Telefone = dados[1];
                        contato.Email = dados[2];

                        contatos.Add(contato);
                    }
                }
            }

            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Telefone: ");
            string telefone = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Contato novoContato = new Contato();

            novoContato.Nome = nome;
            novoContato.Telefone = telefone;
            novoContato.Email = email;

            contatos.Add(novoContato);

            using (StreamWriter escritor = new StreamWriter(arquivo, true))
            {
                escritor.WriteLine(nome + "," + telefone + "," + email);
            }

            Console.WriteLine();
            Console.WriteLine("1 - Markdown");
            Console.WriteLine("2 - Tabela");
            Console.WriteLine("3 - Texto Puro");
            Console.Write("Escolha o formato: ");

            int opcao = int.Parse(Console.ReadLine());

            ContatoFormatter formatter;

            if (opcao == 1)
            {
                formatter = new MarkdownFormatter();
            }
            else if (opcao == 2)
            {
                formatter = new TabelaFormatter();
            }
            else
            {
                formatter = new RawTextFormatter();
            }

            formatter.ExibirContatos(contatos);
        }
    }
}