﻿class Contato
{
    public string Nome;
    public string Telefone;
    public string Email;
}