﻿using System;
using System.Collections.Generic;

class ContatoFormatter
{
    public virtual void ExibirContatos(List<Contato> contatos)
    {
    }
}