﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static string arquivo = "contatos.txt";

    static void Main()
    {
        List<Contato> contatos = LerContatos();

        Console.Write("Deseja cadastrar um novo contato? (s/n): ");
        string resposta = Console.ReadLine();

        if (resposta.ToLower() == "s")
        {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Telefone: ");
            string telefone = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Contato novoContato = new Contato(nome, telefone, email);

            contatos.Add(novoContato);

            SalvarContatos(contatos);

            Console.WriteLine("Contato cadastrado!");
        }

        Console.WriteLine();
        Console.WriteLine("Escolha o formato de exibição:");
        Console.WriteLine("1 - Markdown");
        Console.WriteLine("2 - Tabela");
        Console.WriteLine("3 - Texto Puro");
        Console.Write("Opção: ");

        string opcao = Console.ReadLine();

        ContatoFormatter formatter;

        if (opcao == "1")
        {
            formatter = new MarkdownFormatter();
        }
        else if (opcao == "2")
        {
            formatter = new TabelaFormatter();
        }
        else
        {
            formatter = new RawTextFormatter();
        }

        Console.WriteLine();

        formatter.ExibirContatos(contatos);
    }

    static List<Contato> LerContatos()
    {
        List<Contato> contatos = new List<Contato>();

        if (!File.Exists(arquivo))
        {
            return contatos;
        }

        string[] linhas = File.ReadAllLines(arquivo);

        foreach (string linha in linhas)
        {
            string[] dados = linha.Split(';');

            if (dados.Length == 3)
            {
                Contato contato = new Contato(
                    dados[0],
                    dados[1],
                    dados[2]
                );

                contatos.Add(contato);
            }
        }

        return contatos;
    }

    static void SalvarContatos(List<Contato> contatos)
    {
        List<string> linhas = new List<string>();

        foreach (Contato contato in contatos)
        {
            linhas.Add($"{contato.Nome};{contato.Telefone};{contato.Email}");
        }

        File.WriteAllLines(arquivo, linhas);
    }
}