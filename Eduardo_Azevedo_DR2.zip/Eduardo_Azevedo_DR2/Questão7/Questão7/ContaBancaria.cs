﻿using System;

class ContaBancaria
{
    public string Titular;
    private decimal Saldo;

    public void Depositar(decimal valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine("Depósito de R$ " + valor + " realizado com sucesso!");
        }
        else
        {
            Console.WriteLine("O valor do depósito deve ser positivo!");
        }
    }

    public void Sacar(decimal valor)
    {
        if (valor <= Saldo)
        {
            Saldo -= valor;
            Console.WriteLine("Saque de R$ " + valor + " realizado com sucesso!");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente para realizar o saque!");
        }
    }

    public void ExibirSaldo()
    {
        Console.WriteLine("Saldo atual: R$ " + Saldo);
    }
}