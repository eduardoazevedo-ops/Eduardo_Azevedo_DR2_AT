﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ContaBancaria conta = new ContaBancaria();

            conta.Titular = "Eduardo";

            Console.WriteLine("Titular: " + conta.Titular);

            conta.Depositar(500);
            conta.ExibirSaldo();

            Console.WriteLine("Tentativa de saque: R$ 700");
            conta.Sacar(700);

            conta.Sacar(200);
            conta.ExibirSaldo();
        }
    }
}