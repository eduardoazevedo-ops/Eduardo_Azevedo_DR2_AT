﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite sua data de nascimento (dd/MM/yyyy): ");
            DateTime nascimento = DateTime.ParseExact(
                Console.ReadLine(),
                "dd/MM/yyyy",
                null
            );

            DateTime hoje = DateTime.Today;

            DateTime aniversario = new DateTime(
                hoje.Year,
                nascimento.Month,
                nascimento.Day
            );

            if (aniversario < hoje)
            {
                aniversario = aniversario.AddYears(1);
            }

            int dias = (aniversario - hoje).Days;

            Console.WriteLine(
                "Faltam " + dias +
                " dias para seu próximo aniversário!"
            );

            if (dias < 7)
            {
                Console.WriteLine("Seu aniversário está chegando!");
            }
        }
    }
}