﻿using System;
using System.IO;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string arquivo = "contatos.txt";

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("=== Gerenciador de Contatos ===");
                Console.WriteLine("1 - Adicionar novo contato");
                Console.WriteLine("2 - Listar contatos cadastrados");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha uma opção: ");

                int opcao = int.Parse(Console.ReadLine());

                if (opcao == 1)
                {
                    Console.Write("Nome: ");
                    string nome = Console.ReadLine();

                    Console.Write("Telefone: ");
                    string telefone = Console.ReadLine();

                    Console.Write("Email: ");
                    string email = Console.ReadLine();

                    using (StreamWriter escritor = new StreamWriter(arquivo, true))
                    {
                        escritor.WriteLine(nome + "," + telefone + "," + email);
                    }

                    Console.WriteLine("Contato cadastrado com sucesso!");
                }
                else if (opcao == 2)
                {
                    if (!File.Exists(arquivo))
                    {
                        Console.WriteLine("Nenhum contato cadastrado.");
                    }
                    else
                    {
                        using (StreamReader leitor = new StreamReader(arquivo))
                        {
                            string linha;
                            bool encontrou = false;

                            while ((linha = leitor.ReadLine()) != null)
                            {
                                string[] dados = linha.Split(',');

                                Console.WriteLine(
                                    "Nome: " + dados[0] +
                                    " | Telefone: " + dados[1] +
                                    " | Email: " + dados[2]
                                );

                                encontrou = true;
                            }

                            if (!encontrou)
                            {
                                Console.WriteLine("Nenhum contato cadastrado.");
                            }
                        }
                    }
                }
                else if (opcao == 3)
                {
                    Console.WriteLine("Encerrando programa...");
                    break;
                }
                else
                {
                    Console.WriteLine("Opção inválida!");
                }
            }
        }
    }
}