﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o primeiro número: ");
            double numero1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo número: ");
            double numero2 = double.Parse(Console.ReadLine());

            Console.WriteLine("1 - Soma");
            Console.WriteLine("2 - Subtração");
            Console.WriteLine("3 - Multiplicação");
            Console.WriteLine("4 - Divisão");

            Console.Write("Escolha uma opção: ");
            int opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                Console.WriteLine("Resultado: " + (numero1 + numero2));
            }
            else if (opcao == 2)
            {
                Console.WriteLine("Resultado: " + (numero1 - numero2));
            }
            else if (opcao == 3)
            {
                Console.WriteLine("Resultado: " + (numero1 * numero2));
            }
            else if (opcao == 4)
            {
                if (numero2 == 0)
                    Console.WriteLine("Não é possível dividir por zero!");
                else
                    Console.WriteLine("Resultado: " + (numero1 / numero2));
            }
            else
            {
                Console.WriteLine("Opção inválida!");
            }
        }
    }
}